
-- Course Enrollment System Database Schema
CREATE DATABASE course_enrollment_system;
USE course_enrollment_system;

-- Students Table
CREATE TABLE students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    date_of_birth DATE,
    address TEXT,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Departments Table
CREATE TABLE departments (
    dept_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_name VARCHAR(100) NOT NULL,
    dept_code VARCHAR(10) UNIQUE NOT NULL,
    head_of_dept VARCHAR(100)
);

-- Instructors Table
CREATE TABLE instructors (
    instructor_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    dept_id INT,
    specialization VARCHAR(100),
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
);

-- Courses Table
CREATE TABLE courses (
    course_id INT PRIMARY KEY AUTO_INCREMENT,
    course_code VARCHAR(20) UNIQUE NOT NULL,
    course_name VARCHAR(150) NOT NULL,
    credits INT NOT NULL,
    dept_id INT,
    instructor_id INT,
    max_capacity INT DEFAULT 30,
    available_seats INT DEFAULT 30,
    course_fee DECIMAL(10, 2) NOT NULL,
    semester VARCHAR(20),
    academic_year VARCHAR(10),
    course_description TEXT,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id),
    FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id)
);

-- Enrollments Table
CREATE TABLE enrollments (
    enrollment_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT,
    course_id INT,
    enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    enrollment_status ENUM('ENROLLED', 'WAITLISTED', 'DROPPED') DEFAULT 'ENROLLED',
    payment_status ENUM('PENDING', 'PAID', 'FAILED') DEFAULT 'PENDING',
    grade VARCHAR(5) DEFAULT NULL,
    UNIQUE KEY unique_enrollment (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

-- Payments Table
CREATE TABLE payments (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    enrollment_id INT,
    amount DECIMAL(10, 2) NOT NULL,
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    payment_method VARCHAR(50),
    transaction_id VARCHAR(100),
    payment_status ENUM('PENDING', 'COMPLETED', 'FAILED') DEFAULT 'PENDING',
    FOREIGN KEY (enrollment_id) REFERENCES enrollments(enrollment_id)
);

-- Admin Users Table
CREATE TABLE admin_users (
    admin_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    full_name VARCHAR(100),
    email VARCHAR(100),
    role VARCHAR(50) DEFAULT 'ADMIN',
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample Data Insertion
INSERT INTO departments (dept_name, dept_code, head_of_dept) VALUES
('Computer Science', 'CS', 'Dr. Smith Johnson'),
('Mathematics', 'MATH', 'Dr. Sarah Wilson'),
('Physics', 'PHY', 'Dr. Robert Brown'),
('Chemistry', 'CHEM', 'Dr. Lisa Davis'),
('Engineering', 'ENG', 'Dr. Michael Taylor');

INSERT INTO instructors (first_name, last_name, email, phone, dept_id, specialization) VALUES
('John', 'Anderson', 'john.anderson@college.edu', '555-0101', 1, 'Software Engineering'),
('Emily', 'Clark', 'emily.clark@college.edu', '555-0102', 1, 'Data Structures'),
('David', 'Miller', 'david.miller@college.edu', '555-0103', 2, 'Calculus'),
('Jennifer', 'Garcia', 'jennifer.garcia@college.edu', '555-0104', 3, 'Quantum Physics'),
('Mark', 'Rodriguez', 'mark.rodriguez@college.edu', '555-0105', 4, 'Organic Chemistry');

INSERT INTO courses (course_code, course_name, credits, dept_id, instructor_id, max_capacity, available_seats, course_fee, semester, academic_year, course_description) VALUES
('CS101', 'Introduction to Programming', 4, 1, 1, 30, 30, 1200.00, 'Fall', '2025', 'Basic programming concepts using Java'),
('CS201', 'Data Structures and Algorithms', 4, 1, 2, 25, 25, 1400.00, 'Spring', '2025', 'Advanced data structures and algorithmic thinking'),
('MATH101', 'Calculus I', 3, 2, 3, 35, 35, 1000.00, 'Fall', '2025', 'Differential and integral calculus'),
('PHY101', 'Physics I', 4, 3, 4, 20, 20, 1300.00, 'Fall', '2025', 'Mechanics and thermodynamics'),
('CHEM101', 'General Chemistry', 3, 4, 5, 25, 25, 1100.00, 'Spring', '2025', 'Basic chemical principles and reactions'),
('CS301', 'Database Systems', 3, 1, 1, 20, 20, 1500.00, 'Fall', '2025', 'Database design and management'),
('MATH201', 'Linear Algebra', 3, 2, 3, 30, 30, 1150.00, 'Spring', '2025', 'Vector spaces and matrix operations');

INSERT INTO admin_users (username, password, full_name, email, role) VALUES
('admin', 'admin123', 'System Administrator', 'admin@college.edu', 'ADMIN'),
('registrar', 'reg123', 'Registrar Office', 'registrar@college.edu', 'REGISTRAR');

-- Sample student data
INSERT INTO students (first_name, last_name, email, phone, date_of_birth, address) VALUES
('Alice', 'Johnson', 'alice.johnson@student.edu', '555-1001', '2003-05-15', '123 Main St, City'),
('Bob', 'Williams', 'bob.williams@student.edu', '555-1002', '2002-08-22', '456 Oak Ave, City'),
('Charlie', 'Brown', 'charlie.brown@student.edu', '555-1003', '2003-01-10', '789 Pine Rd, City');
