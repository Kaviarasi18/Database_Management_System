# Course Enrollment System

A comprehensive Course Enrollment System built with **Java Swing** (Frontend) and **MySQL** (Backend).

## 🚀 Features

### Student Features
- Student Registration with personal details
- Login System using email authentication  
- Course Browsing with instructor and fee details
- Course Enrollment with seat allocation
- Payment Processing with multiple payment methods
- Enrollment Management (view and drop courses)

### Admin Features
- Admin Dashboard for system management
- Student Management (view all registered students)
- Course Management (manage courses and instructors) 
- Enrollment Tracking (monitor all enrollments)
- Payment Monitoring (track transactions)
- Data Export (export student data to CSV)

## 🛠️ Technology Stack
- **Frontend**: Java Swing (GUI)
- **Backend**: Java with JDBC
- **Database**: MySQL
- **Architecture**: MVC Pattern

## 📋 Prerequisites
1. **Java JDK** - Version 8+
2. **MySQL Server** - Version 5.7+
3. **MySQL Connector/J** - JDBC Driver
4. **IDE** - Eclipse/NetBeans/IntelliJ

## 🔧 Installation & Setup

### 1. Database Setup
```sql
mysql -u root -p
source database/course_enrollment_database.sql
```

### 2. Project Setup
1. Import project into your IDE
2. Add MySQL Connector/J to classpath
3. Update database credentials in DatabaseConnection.java

### 3. Run Application
```bash
# Compile
javac -cp ".:mysql-connector-java-x.x.x.jar" src/com/courseenrollment/gui/LoginForm.java

# Run  
java -cp ".:mysql-connector-java-x.x.x.jar:src" com.courseenrollment.gui.LoginForm
```

## 👥 Default Login Credentials

### Admin Login
- **Username**: `admin`
- **Password**: `admin123`

### Student Login
- Register first, then login with email

## 📱 Usage Guide

### For Students:
1. **Register**: Click "New Student Registration" 
2. **Login**: Use your email to login
3. **Browse**: View available courses
4. **Enroll**: Select course and enroll
5. **Pay**: Make payment for enrolled courses

### For Administrators:
1. **Login**: Use admin credentials
2. **Monitor**: View students, courses, enrollments, payments
3. **Manage**: Export data and oversee operations

## 🔒 Security Features
- Input Validation on all forms
- SQL Injection Prevention using PreparedStatements
- Payment Security with validation
- Role-based Access Control

## 📞 Support
For issues:
- Check database connection
- Verify MySQL Connector/J in classpath
- Review troubleshooting in documentation

**Created for educational purposes demonstrating Java Swing with MySQL integration.**
