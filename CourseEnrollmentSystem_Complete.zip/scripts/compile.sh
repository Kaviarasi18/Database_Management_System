#!/bin/bash
echo "Course Enrollment System - Build Script"
echo "======================================"

if ! ls lib/mysql-connector-java-*.jar 1> /dev/null 2>&1; then
    echo "ERROR: MySQL Connector JAR not found in lib/ directory!"
    exit 1
fi

echo "Compiling Java files..."
mkdir -p bin
javac -d bin -cp ".:lib/mysql-connector-java-*.jar" src/com/courseenrollment/*/*.java

if [ $? -ne 0 ]; then
    echo "ERROR: Compilation failed!"
    exit 1
fi

echo "Compilation successful!"
echo "To run: java -cp \"bin:lib/mysql-connector-java-*.jar\" com.courseenrollment.gui.LoginForm"