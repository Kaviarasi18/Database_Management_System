package com.courseenrollment.gui;

import javax.swing.*;
import java.awt.*;
import java.math.BigDecimal;

public class PaymentForm extends JDialog {

    private StudentDashboard parentFrame;
    private int studentId;
    private String courseCode;
    private BigDecimal amount;

    public PaymentForm(StudentDashboard parent, int studentId, String courseCode, BigDecimal amount) {
        super(parent, "Payment Processing", true);
        this.parentFrame = parent;
        this.studentId = studentId;
        this.courseCode = courseCode;
        this.amount = amount;

        setSize(400, 300);
        setLocationRelativeTo(parent);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2, 10, 10));

        panel.add(new JLabel("Course: " + courseCode));
        panel.add(new JLabel("Amount: $" + amount));

        panel.add(new JLabel("Card Number:"));
        JTextField cardField = new JTextField();
        panel.add(cardField);

        panel.add(new JLabel("Cardholder Name:"));
        panel.add(new JTextField());

        JButton payButton = new JButton("Process Payment");
        payButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Payment Processed Successfully!");
            parentFrame.refreshAfterPayment();
            dispose();
        });
        panel.add(payButton);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dispose());
        panel.add(cancelButton);

        add(panel);
    }
}