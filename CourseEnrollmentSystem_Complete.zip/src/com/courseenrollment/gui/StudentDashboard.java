package com.courseenrollment.gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.courseenrollment.database.DatabaseConnection;

public class StudentDashboard extends JFrame {

    private int studentId;
    private String studentName, studentEmail;
    private JTable coursesTable, enrolledCoursesTable;
    private DefaultTableModel coursesModel, enrolledModel;

    public StudentDashboard(int studentId, String studentName, String studentEmail) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentEmail = studentEmail;

        setTitle("Student Dashboard - " + studentName);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 700);

        initializeComponents();
        loadData();
        setLocationRelativeTo(null);
    }

    private void initializeComponents() {
        JPanel contentPane = new JPanel(new BorderLayout());
        setContentPane(contentPane);

        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(51, 102, 153));
        headerPanel.add(new JLabel("Welcome, " + studentName + "!"));
        contentPane.add(headerPanel, BorderLayout.NORTH);

        // Tabbed pane
        JTabbedPane tabbedPane = new JTabbedPane();

        // Available courses tab
        String[] courseColumns = {"Code", "Name", "Credits", "Instructor", "Fee", "Seats"};
        coursesModel = new DefaultTableModel(courseColumns, 0);
        coursesTable = new JTable(coursesModel);
        tabbedPane.addTab("Available Courses", new JScrollPane(coursesTable));

        // Enrolled courses tab  
        String[] enrolledColumns = {"Code", "Name", "Status", "Payment"};
        enrolledModel = new DefaultTableModel(enrolledColumns, 0);
        enrolledCoursesTable = new JTable(enrolledModel);
        tabbedPane.addTab("My Enrollments", new JScrollPane(enrolledCoursesTable));

        contentPane.add(tabbedPane, BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel();
        JButton enrollButton = new JButton("Enroll in Course");
        enrollButton.addActionListener(e -> enrollInSelectedCourse());
        buttonPanel.add(enrollButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(e -> logout());
        buttonPanel.add(logoutButton);

        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadData() {
        loadAvailableCourses();
        loadEnrolledCourses();
    }

    private void loadAvailableCourses() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT course_code, course_name, credits, course_fee, available_seats FROM courses WHERE available_seats > 0";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            coursesModel.setRowCount(0);
            while (resultSet.next()) {
                coursesModel.addRow(new Object[]{
                    resultSet.getString("course_code"),
                    resultSet.getString("course_name"), 
                    resultSet.getInt("credits"),
                    "Instructor",
                    "$" + resultSet.getBigDecimal("course_fee"),
                    resultSet.getInt("available_seats")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading courses: " + e.getMessage());
        }
    }

    private void loadEnrolledCourses() {
        // Implementation for loading enrolled courses
    }

    private void enrollInSelectedCourse() {
        int row = coursesTable.getSelectedRow();
        if (row >= 0) {
            String courseCode = (String) coursesModel.getValueAt(row, 0);
            // Implementation for enrollment
            JOptionPane.showMessageDialog(this, "Enrollment feature - Course: " + courseCode);
        }
    }

    private void logout() {
        dispose();
        new LoginForm().setVisible(true);
    }

    public void refreshAfterPayment() {
        loadData();
    }
}