package com.courseenrollment.gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.courseenrollment.database.DatabaseConnection;

/**
 * Login Form Class - Main entry point for the Course Enrollment System
 */
public class LoginForm extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> userTypeComboBox;
    private JButton loginButton;
    private JButton registerButton;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeel());
                LoginForm frame = new LoginForm();
                frame.setVisible(true);
                frame.setLocationRelativeTo(null);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public LoginForm() {
        setTitle("Course Enrollment System - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 500, 400);
        setResizable(false);

        JPanel contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        contentPane.setBackground(new Color(245, 245, 245));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title Label
        JLabel titleLabel = new JLabel("Course Enrollment System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBounds(50, 20, 400, 40);
        titleLabel.setForeground(new Color(51, 102, 153));
        contentPane.add(titleLabel);

        // User Type
        JLabel userTypeLabel = new JLabel("Login As:");
        userTypeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        userTypeLabel.setBounds(80, 80, 80, 25);
        contentPane.add(userTypeLabel);

        userTypeComboBox = new JComboBox<>();
        userTypeComboBox.setModel(new DefaultComboBoxModel<>(new String[] {"Student", "Admin"}));
        userTypeComboBox.setBounds(170, 80, 250, 25);
        contentPane.add(userTypeComboBox);

        // Username
        JLabel usernameLabel = new JLabel("Username/Email:");
        usernameLabel.setBounds(80, 130, 120, 25);
        contentPane.add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(80, 160, 340, 30);
        contentPane.add(usernameField);

        // Password
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(80, 210, 80, 25);
        contentPane.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(80, 240, 340, 30);
        contentPane.add(passwordField);

        // Login Button
        loginButton = new JButton("Login");
        loginButton.setBounds(80, 300, 150, 35);
        loginButton.setBackground(new Color(51, 102, 153));
        loginButton.setForeground(Color.WHITE);
        loginButton.addActionListener(this::loginAction);
        contentPane.add(loginButton);

        // Register Button
        registerButton = new JButton("New Student Registration");
        registerButton.setBounds(250, 300, 170, 35);
        registerButton.setBackground(new Color(34, 139, 34));
        registerButton.setForeground(Color.WHITE);
        registerButton.addActionListener(this::registerAction);
        contentPane.add(registerButton);

        if (!DatabaseConnection.testConnection()) {
            JOptionPane.showMessageDialog(this, "Database connection failed!");
        }
    }

    private void loginAction(ActionEvent e) {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String userType = (String) userTypeComboBox.getSelectedItem();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter username and password.");
            return;
        }

        if ("Admin".equals(userType)) {
            authenticateAdmin(username, password);
        } else {
            authenticateStudent(username, password);
        }
    }

    private void registerAction(ActionEvent e) {
        dispose();
        StudentRegistrationForm registrationForm = new StudentRegistrationForm();
        registrationForm.setVisible(true);
    }

    private void authenticateAdmin(String username, String password) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT admin_id, full_name FROM admin_users WHERE username = ? AND password = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                int adminId = resultSet.getInt("admin_id");
                String fullName = resultSet.getString("full_name");

                JOptionPane.showMessageDialog(this, "Welcome, " + fullName + "!");
                dispose();
                AdminDashboard adminDashboard = new AdminDashboard(adminId, fullName);
                adminDashboard.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid admin credentials!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }
    }

    private void authenticateStudent(String email, String password) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT student_id, first_name, last_name FROM students WHERE email = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, email);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                int studentId = resultSet.getInt("student_id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                String fullName = firstName + " " + lastName;

                JOptionPane.showMessageDialog(this, "Welcome, " + fullName + "!");
                dispose();
                StudentDashboard studentDashboard = new StudentDashboard(studentId, fullName, email);
                studentDashboard.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Student not found! Please register first.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }
    }
}