package com.courseenrollment.gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.courseenrollment.database.DatabaseConnection;

public class AdminDashboard extends JFrame {

    private int adminId;
    private String adminName;
    private DefaultTableModel studentsModel, coursesModel;

    public AdminDashboard(int adminId, String adminName) {
        this.adminId = adminId;
        this.adminName = adminName;

        setTitle("Admin Dashboard - " + adminName);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1200, 800);

        initializeComponents();
        loadAllData();
        setLocationRelativeTo(null);
    }

    private void initializeComponents() {
        JPanel contentPane = new JPanel(new BorderLayout());
        setContentPane(contentPane);

        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(51, 102, 153));
        headerPanel.add(new JLabel("Admin Dashboard - " + adminName));
        contentPane.add(headerPanel, BorderLayout.NORTH);

        // Tabbed pane
        JTabbedPane tabbedPane = new JTabbedPane();

        // Students tab
        String[] studentColumns = {"ID", "Name", "Email", "Phone", "Registration Date"};
        studentsModel = new DefaultTableModel(studentColumns, 0);
        JTable studentsTable = new JTable(studentsModel);
        tabbedPane.addTab("Students", new JScrollPane(studentsTable));

        // Courses tab
        String[] courseColumns = {"ID", "Code", "Name", "Credits", "Capacity", "Fee"};
        coursesModel = new DefaultTableModel(courseColumns, 0);
        JTable coursesTable = new JTable(coursesModel);
        tabbedPane.addTab("Courses", new JScrollPane(coursesTable));

        contentPane.add(tabbedPane, BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel();
        JButton refreshButton = new JButton("Refresh All Data");
        refreshButton.addActionListener(e -> loadAllData());
        buttonPanel.add(refreshButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.addActionListener(e -> {
            dispose();
            new LoginForm().setVisible(true);
        });
        buttonPanel.add(logoutButton);

        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadAllData() {
        loadStudentsData();
        loadCoursesData();
    }

    private void loadStudentsData() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT student_id, CONCAT(first_name, ' ', last_name) as name, email, phone, registration_date FROM students";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            studentsModel.setRowCount(0);
            while (resultSet.next()) {
                studentsModel.addRow(new Object[]{
                    resultSet.getInt("student_id"),
                    resultSet.getString("name"),
                    resultSet.getString("email"),
                    resultSet.getString("phone"),
                    resultSet.getTimestamp("registration_date")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading students: " + e.getMessage());
        }
    }

    private void loadCoursesData() {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT course_id, course_code, course_name, credits, max_capacity, course_fee FROM courses";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            coursesModel.setRowCount(0);
            while (resultSet.next()) {
                coursesModel.addRow(new Object[]{
                    resultSet.getInt("course_id"),
                    resultSet.getString("course_code"),
                    resultSet.getString("course_name"),
                    resultSet.getInt("credits"),
                    resultSet.getInt("max_capacity"),
                    "$" + resultSet.getBigDecimal("course_fee")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading courses: " + e.getMessage());
        }
    }
}