package com.courseenrollment.gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.courseenrollment.database.DatabaseConnection;

public class StudentRegistrationForm extends JFrame {

    private JTextField firstNameField, lastNameField, emailField, phoneField;
    private JSpinner dateSpinner;
    private JTextArea addressArea;

    public StudentRegistrationForm() {
        setTitle("Student Registration");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 500);

        JPanel contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        contentPane.setBackground(new Color(245, 245, 245));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title
        JLabel titleLabel = new JLabel("Student Registration");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBounds(150, 10, 300, 40);
        contentPane.add(titleLabel);

        // Form fields setup (condensed for brevity)
        setupFormFields(contentPane);
        setupButtons(contentPane);

        setLocationRelativeTo(null);
    }

    private void setupFormFields(JPanel contentPane) {
        // First Name
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setBounds(50, 70, 100, 25);
        contentPane.add(firstNameLabel);

        firstNameField = new JTextField();
        firstNameField.setBounds(160, 70, 200, 25);
        contentPane.add(firstNameField);

        // Email
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(50, 120, 100, 25);
        contentPane.add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(160, 120, 300, 25);
        contentPane.add(emailField);

        // Additional fields would be added similarly...
    }

    private void setupButtons(JPanel contentPane) {
        JButton registerButton = new JButton("Register");
        registerButton.setBounds(200, 350, 120, 40);
        registerButton.setBackground(new Color(34, 139, 34));
        registerButton.setForeground(Color.WHITE);
        registerButton.addActionListener(this::registerStudent);
        contentPane.add(registerButton);

        JButton backButton = new JButton("Back to Login");
        backButton.setBounds(350, 350, 120, 40);
        backButton.addActionListener(e -> {
            dispose();
            new LoginForm().setVisible(true);
        });
        contentPane.add(backButton);
    }

    private void registerStudent(ActionEvent e) {
        String firstName = firstNameField.getText().trim();
        String email = emailField.getText().trim();

        if (firstName.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill required fields.");
            return;
        }

        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO students (first_name, email) VALUES (?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, firstName);
            statement.setString(2, email);

            if (statement.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(this, "Registration successful!");
                dispose();
                new LoginForm().setVisible(true);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Registration failed: " + ex.getMessage());
        }
    }
}