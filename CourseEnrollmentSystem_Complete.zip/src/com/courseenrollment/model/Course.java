package com.courseenrollment.model;

import java.math.BigDecimal;

/**
 * Course Model Class
 * Represents a course entity in the Course Enrollment System
 */
public class Course {

    private int courseId;
    private String courseCode;
    private String courseName;
    private int credits;
    private int deptId;
    private int instructorId;
    private int maxCapacity;
    private int availableSeats;
    private BigDecimal courseFee;
    private String semester;
    private String academicYear;
    private String courseDescription;
    private String instructorName;
    private String departmentName;

    // Default Constructor
    public Course() {}

    // Parameterized Constructor
    public Course(String courseCode, String courseName, int credits, int deptId,
                  int instructorId, int maxCapacity, BigDecimal courseFee,
                  String semester, String academicYear, String courseDescription) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.credits = credits;
        this.deptId = deptId;
        this.instructorId = instructorId;
        this.maxCapacity = maxCapacity;
        this.availableSeats = maxCapacity;
        this.courseFee = courseFee;
        this.semester = semester;
        this.academicYear = academicYear;
        this.courseDescription = courseDescription;
    }

    // Getters and Setters
    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }

    public String getCourseCode() { return courseCode; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; }

    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public int getCredits() { return credits; }
    public void setCredits(int credits) { this.credits = credits; }

    public int getDeptId() { return deptId; }
    public void setDeptId(int deptId) { this.deptId = deptId; }

    public int getInstructorId() { return instructorId; }
    public void setInstructorId(int instructorId) { this.instructorId = instructorId; }

    public int getMaxCapacity() { return maxCapacity; }
    public void setMaxCapacity(int maxCapacity) { this.maxCapacity = maxCapacity; }

    public int getAvailableSeats() { return availableSeats; }
    public void setAvailableSeats(int availableSeats) { this.availableSeats = availableSeats; }

    public BigDecimal getCourseFee() { return courseFee; }
    public void setCourseFee(BigDecimal courseFee) { this.courseFee = courseFee; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }

    public String getAcademicYear() { return academicYear; }
    public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }

    public String getCourseDescription() { return courseDescription; }
    public void setCourseDescription(String courseDescription) { this.courseDescription = courseDescription; }

    public String getInstructorName() { return instructorName; }
    public void setInstructorName(String instructorName) { this.instructorName = instructorName; }

    public String getDepartmentName() { return departmentName; }
    public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }

    public boolean isAvailable() { return availableSeats > 0; }

    @Override
    public String toString() {
        return courseCode + " - " + courseName + " (" + credits + " credits)";
    }
}